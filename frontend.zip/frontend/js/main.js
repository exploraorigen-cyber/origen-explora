/* =========================================
   ORIGEN
   JAVASCRIPT PRINCIPAL
========================================= */


/* =========================================
   ELEMENTOS
========================================= */

const pathOptions =
    document.querySelectorAll(".path-option");

const pathsBackground =
    document.querySelector(".paths-background");

const previewNumber =
    document.querySelector("#path-preview-number");

const previewTitle =
    document.querySelector("#path-preview-title");

const previewDescription =
    document.querySelector("#path-preview-description");

const progressBar =
    document.querySelector(".scroll-progress span");


/* =========================================
   ESTADO INICIAL
========================================= */

function updatePath(option) {

    if (!option) return;


    pathOptions.forEach((item) => {

        item.classList.remove("active");

    });


    option.classList.add("active");


    const pathName =
        option.dataset.path;

    const image =
        option.dataset.image;

    const title =
        option.dataset.title;

    const description =
        option.dataset.description;


    /* Número */

    const index =
        Array.from(pathOptions)
            .indexOf(option) + 1;


    const formattedIndex =
        String(index).padStart(2, "0");


    previewNumber.textContent =
        `${formattedIndex} / CAMINO`;


    /* Contenido */

    previewTitle.textContent =
        title;

    previewDescription.textContent =
        description;


    /* Fondo */

    if (image) {

        pathsBackground.style.setProperty(
            "--active-path-image",
            `url("${image}")`
        );

        pathsBackground.classList.add(
            "visible"
        );

    }


    /* Identificador para futuras funciones */

    document.body.dataset.activePath =
        pathName;

}


/* =========================================
   INTERACCIÓN CON CAMINOS
========================================= */

pathOptions.forEach((option) => {


    /* PC */

    option.addEventListener(
        "mouseenter",
        () => {

            if (
                window.matchMedia(
                    "(hover: hover)"
                ).matches
            ) {

                updatePath(option);

            }

        }
    );


    /* CLICK / MÓVIL */

    option.addEventListener(
        "click",
        () => {

            updatePath(option);

        }
    );


    /* TECLADO */

    option.addEventListener(
        "focus",
        () => {

            updatePath(option);

        }
    );


});


/* =========================================
   CAMINO INICIAL
========================================= */

const initialPath =
    document.querySelector(
        ".path-option.active"
    );


updatePath(initialPath);


/* =========================================
   PROGRESO DE SCROLL
========================================= */

function updateScrollProgress() {

    const scrollTop =
        window.scrollY;

    const documentHeight =
        document.documentElement.scrollHeight
        - window.innerHeight;


    if (documentHeight <= 0) {

        progressBar.style.width = "0%";

        return;

    }


    const progress =
        (scrollTop / documentHeight)
        * 100;


    progressBar.style.width =
        `${progress}%`;

}


window.addEventListener(
    "scroll",
    updateScrollProgress,
    {
        passive: true
    }
);


updateScrollProgress();


/* =========================================
   MENÚ
   Base preparada para futura navegación
========================================= */

const menuButton =
    document.querySelector(".menu-btn");


menuButton.addEventListener(
    "click",
    () => {

        console.log(
            "Menú ORIGEN: próximamente."
        );

    }
);